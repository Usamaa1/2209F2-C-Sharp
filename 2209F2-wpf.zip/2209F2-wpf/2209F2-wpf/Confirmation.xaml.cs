﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _2209F2_wpf
{
    /// <summary>
    /// Interaction logic for Confirmation.xaml
    /// </summary>
    public partial class Confirmation : Window
    {
        public Confirmation()
        {
            InitializeComponent();
        }
        public class Connectivity
        {
            public static SqlConnection connect = new SqlConnection("Data Source=(localdb)\\ProjectModels;Initial Catalog=stdInfo;Integrated Security=True;Connect Timeout=30;");
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            Connectivity.connect.Open();
            SqlCommand deleteQuery = new SqlCommand("DELETE FROM student WHERE id = @id",Connectivity.connect);
            deleteQuery.Parameters.AddWithValue("@id", cnfrmId.Content);

            int row = deleteQuery.ExecuteNonQuery();
            
            if(row > 0)
            {
                MessageBox.Show("Your Item is Deleted");
            }
            else
            {
                MessageBox.Show("Your Items is not Deleted");
            }


            Connectivity.connect.Close();

            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _2209F2_wpf
{
    /// <summary>
    /// Interaction logic for dataForm.xaml
    /// </summary>
    public partial class dataForm : Window
    {
        public dataForm()
        {
            InitializeComponent();
        }

        private void dataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataRowView dataRow = dataGrid.SelectedValue as DataRowView;

            OptionForm optionForm = new OptionForm();
            optionForm.Show();
            optionForm.opStdId.Content = dataRow["id"];
            optionForm.opStdName.Content = dataRow["stdName"];
            optionForm.opStdRollNumber.Content = dataRow["stdRollNumber"];
            optionForm.opStdAge.Content = dataRow["stdAge"];

            Close();
        }
    }
}

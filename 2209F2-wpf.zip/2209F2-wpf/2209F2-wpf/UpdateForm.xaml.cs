﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static _2209F2_wpf.MainWindow;

namespace _2209F2_wpf
{
    /// <summary>
    /// Interaction logic for UpdateForm.xaml
    /// </summary>
    public partial class UpdateForm : Window
    {
        public UpdateForm()
        {
            InitializeComponent();
        }
        public class Connectivity
        {
            public static SqlConnection connect = new SqlConnection("Data Source=(localdb)\\ProjectModels;Initial Catalog=stdInfo;Integrated Security=True;Connect Timeout=30;");
        }


        private void updateBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Connectivity.connect.Open();
                SqlCommand updateQuery = new SqlCommand("UPDATE student SET stdName = @stdName, stdRollNumber = @stdRoll, stdAge = @stdAge WHERE id = @id", Connectivity.connect);

                updateQuery.Parameters.AddWithValue("@id", upId.Content);
                updateQuery.Parameters.AddWithValue("@stdName", upName.Text);
                updateQuery.Parameters.AddWithValue("@stdRoll", upRoll.Text);
                updateQuery.Parameters.AddWithValue("@stdAge", upAge.Text);

                int row = updateQuery.ExecuteNonQuery();

                if (row > 0)
                {
                    MessageBox.Show("Your Data Updated Successfully");

                    dataForm dataForm = new dataForm();


                    SqlCommand viewQuery = new SqlCommand("SELECT * FROM student", Connectivity.connect);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(viewQuery);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataForm.dataGrid.ItemsSource = dataTable.DefaultView;

                    dataForm.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("Data Updation Failed");
                }


                Connectivity.connect.Close();


            }
            catch (System.InvalidOperationException er)
            {
                MessageBox.Show(er.ToString());
            }
            Close();
        }
    }
}

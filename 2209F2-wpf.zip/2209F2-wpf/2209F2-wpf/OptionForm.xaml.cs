﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _2209F2_wpf
{
    /// <summary>
    /// Interaction logic for OptionForm.xaml
    /// </summary>
    public partial class OptionForm : Window
    {
        public OptionForm()
        {
            InitializeComponent();
        }
        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UpdateForm updateForm = new UpdateForm();
            updateForm.Show();

            updateForm.upId.Content = opStdId.Content.ToString();
            updateForm.upName.Text = opStdName.Content.ToString();
            updateForm.upRoll.Text = opStdRollNumber.Content.ToString();
            updateForm.upAge.Text = opStdAge.Content.ToString();

            Close();
        }

        private void deleteBtn_Click(object sender, RoutedEventArgs e)
        {

            Confirmation confirmation = new Confirmation();
            confirmation.Show();
            confirmation.cnfrmId.Content = opStdId.Content.ToString();


            Close();


        }
    }
}
